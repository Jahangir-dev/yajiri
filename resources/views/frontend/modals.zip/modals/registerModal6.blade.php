<!-- <div class="modal fade" id="LoginRegisterModal7" tabindex="-1" aria-labelledby="LoginRegisterModal7Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <p class="modal-title" id="LoginRegisterModal7Label">Create your profile</p>
                </div>
                <div class="Modal7Body modal-body">
                    <p class="Modal6Text1 text-center"><b>Check your email</b></p>
                    


                        <span id="sendedphoneNumberAlert" style="color:green;font-size: 11px;">Verification code has been sent to email <span id="phoneNumbersent"></span></span>
                        <p class="Moda3Text1">Enter the code sent to your email </p>
                        <div class="Modal3IputDIV d-flex">
                            <input type="text" style="text-align:center;" size="1" maxlength="1" class="email_Number_code Model3input form-control" placeholder="1" aria-label="1">
                            <input type="text" style="text-align:center;" size="1" maxlength="1" class="email_Number_code Model3input form-control" placeholder="2" aria-label="2">
                            <input type="text" style="text-align:center;" size="1" maxlength="1" class="email_Number_code Model3input form-control" placeholder="3" aria-label="3">
                            <input type="text" style="text-align:center;" size="1" maxlength="1" class="email_Number_code Model3input form-control" placeholder="4" aria-label="4">
                            <input type="text" style="text-align:center;" size="1" maxlength="1" class="email_Number_code Model3input form-control" placeholder="5" aria-label="5">
                            <input type="text" style="text-align:center;" size="1" maxlength="1" class="email_Number_code Model3input form-control" placeholder="6" aria-label="6">
                        </div>
                        <span id="notmatchedsendedemailAlert" style="color:red;font-size: 11px;display: none;">Verification doesnot match</span> <span id="matchedsendedemailAlert" style="color:green;font-size: 11px;display: none;">Verification matched</span>                        
                    


                    <p class="Modal6Text2 mb-5">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document</p>
                    <div class="LRM1Button row" style="margin: auto;">
                        <a role="button" href="#" id="registerModal6Continuebtn" style="text-decoration:none;">
                            <p style="color: white;margin-top: 10px;">Continue</p>
                        </a>
                    </div>



                    <div class="row" style="margin: auto;">
                        <a role="button" data-bs-target="#LoginRegisterModal2" data-bs-toggle="modal" data-bs-dismiss="modal">
                            <p class="text-center pt-2" style="font-size: 12px;"><b>Update Email</b></p>
                        </a>
                    </div>
                </div>
                <div class="modal-footer" style="margin: auto;border: none;">
                    <div class="row">
                        <img src="{{asset('theme/icons/yajari-removebg-preview.png')}}">
                    </div>
                </div>
            </div>
        </div>
    </div> -->




    <div class="modal fade" id="LoginRegisterModal7" tabindex="-1" aria-labelledby="LoginRegisterModal7Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <p class="modal-title" id="LoginRegisterModal7Label">Create your profile</p>
                </div>
                <div class="Modal7Body modal-body">
                    <p class="Modal6Text1 text-center"><b>Verification Email</b></p>
                    


                        <span id="sendedphoneNumberAlert" style="color:green;font-size: 11px;">To Activate Account, Verify Your Email <span id="phoneNumbersent"></span></span>
                        <p class="Moda3Text1">Verification Email will be sent after successfull registration</p>
                        
                        <div class="LRM1Button row" style="margin: auto;">
                            <a role="button" href="#" id="registerModal6Continuebtn" style="text-decoration:none;">
                                <p style="color: white;margin-top: 10px;">Continue</p>
                            </a>
                        </div>



                    <div class="row" style="margin: auto;">
                        <a role="button" data-bs-target="#LoginRegisterModal2" data-bs-toggle="modal" data-bs-dismiss="modal">
                            <p class="text-center pt-2" style="font-size: 12px;"><b>Update Email</b></p>
                        </a>
                    </div>
                </div>
                <div class="modal-footer" style="margin: auto;border: none;">
                    <div class="row">
                        <img src="{{asset('theme/icons/yajari-removebg-preview.png')}}">
                    </div>
                </div>
            </div>
        </div>
    </div>