<div class="modal fade" id="LoginRegisterModal5" data-bs-keyboard="false" tabindex="-1" aria-labelledby="LoginRegisterModal5Label" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="MHmodel3 modal-header row">
                        <div class="col-3 col-sm-4">
                            <button type="button" data-bs-dismiss="modal" class="reloadModal" aria-label="Close" style="background-color: white;border: none;">
                                <img class="model-img1" src="{{asset('theme/icons/ic_keyboard_arrow_right_24Blackpx.png')}}">
                            </button>
                        </div>
                        <div class="col-9 col-sm-8">
                            <p class="modal-title text-startt" id="LoginRegisterModal5Label">Create your profile</p>
                        </div>
                    </div>
                    <div class="Modal5Body modal-body">
                        <div class="row" style="margin: auto;">
                            <img class="Modal5Img" src="{{asset('theme/icons/yajari-removebg-preview.png')}}">
                        </div>
                        <p class="Modal5Text1 pt-1"><b>Welcome to Yajari</b></p>
                        <p class="Modal5Text2">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document </p>
                        <div class="LRM1Button row" style="margin-bottom: 0.2rem;">
                            <a role="button" id="LoginRegisterModal6" data-bs-dismiss="modal">
                                <p style="color: white;margin-top: 10px;">Continue</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>